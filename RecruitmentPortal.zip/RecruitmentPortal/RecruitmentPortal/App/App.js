﻿var app = angular.module('loginApp', ['ngRoute']);

